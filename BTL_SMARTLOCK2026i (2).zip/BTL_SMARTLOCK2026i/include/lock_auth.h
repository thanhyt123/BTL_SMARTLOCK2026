#ifndef LOCK_AUTH_H
#define LOCK_AUTH_H

#define AUTH_SUCCESS 1
#define AUTH_FAIL 0
#define ERR_INVALID_LEN -1

int verify_pin(const char *input_pin, const char *master_pin);
int change_master_pin(char *current_master, const char *old_pin, const char *new_pin);

#endif // LOCK_AUTH_H