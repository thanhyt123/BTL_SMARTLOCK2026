#ifndef LOCK_LOGGER_H
#define LOCK_LOGGER_H

#include <stdint.h>

typedef struct {
    uint32_t timestamp;
    char event_msg[256];
    uint8_t is_encrypted;
} LogEntry;

typedef struct {
    LogEntry *entries;
    uint32_t count;
    uint32_t capacity;
} LockLogger;

LockLogger* logger_init(uint32_t initial_capacity);
void log_event(LockLogger *logger, const char *msg);
void encrypt_logs(LockLogger *logger, uint8_t key);
void free_logger(LockLogger *logger);

#endif // LOCK_LOGGER_H