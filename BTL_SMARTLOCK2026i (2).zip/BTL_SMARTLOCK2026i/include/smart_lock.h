#ifndef SMART_LOCK_H
#define SMART_LOCK_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

typedef enum {
    STATE_LOCKED = 0,
    STATE_UNLOCKING,
    STATE_UNLOCKED,
    STATE_ALARM
} LockState;

typedef struct {
    LockState current_state;
    uint8_t failed_attempts;
    char master_pin[7];
    uint8_t is_alarm_triggered;
} SmartLock;

void smart_lock_init(SmartLock *lock, const char *master_pin);
int process_pin_entry(SmartLock *lock, const char *input_pin);
void trigger_alarm(SmartLock *lock);
void reset_alarm(SmartLock *lock, const char *master_pin);

#endif // SMART_LOCK_H