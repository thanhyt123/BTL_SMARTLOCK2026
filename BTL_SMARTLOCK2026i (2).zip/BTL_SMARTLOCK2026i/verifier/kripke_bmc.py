from z3 import *

def run_kripke_bmc():
    print("[*] Bounded Model Checking (BMC) cho May Trang thai Kripke (k=5)...")
    K = 5
    states = [Int(f"state_{i}") for i in range(K + 1)]
    failed = [Int(f"failed_{i}") for i in range(K + 1)]
    
    s = Solver()
    s.add(states[0] == 0) # LOCKED
    s.add(failed[0] == 0)
    
    for i in range(K):
        # Chuyển trạng thái ALARM nếu thử sai >= 3
        s.add(Implies(failed[i] >= 3, states[i+1] == 3))
        
    result = s.check()
    print("[+] BMC Result:", result)

if __name__ == "__main__":
    run_kripke_bmc()