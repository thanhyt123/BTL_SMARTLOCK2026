import os
import random
import string
import subprocess

def generate_random_pin(length=4):
    return ''.join(random.choices(string.digits, k=length))

def run_blackbox_fuzzer(iterations=100):
    print(f"[+] Starting Blackbox Fuzzing on smart_lock.exe ({iterations} iterations)...")
    
    target_bin = "./smart_lock.exe"
    if not os.path.exists("smart_lock.exe"):
        print("[-] Error: Target executable 'smart_lock.exe' not found. Please build the project first.")
        return

    crashes = 0
    for i in range(iterations):
        test_pin = generate_random_pin(random.randint(1, 16))
        
        try:
            # Goi thuc thi thong qua WSL de tuong thich binary Linux/WSL
            process = subprocess.Popen(
                ["wsl", target_bin],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            stdout, stderr = process.communicate(input=f"{test_pin}\n", timeout=2)
            
            if process.returncode != 0 and process.returncode is not None:
                print(f"[!] Crash/Error detected at iteration {i+1} with input: {test_pin}")
                crashes += 1

        except subprocess.TimeoutExpired:
            process.kill()
            print(f"[!] Timeout detected at iteration {i+1} with input: {test_pin}")
        except Exception as e:
            # Fallback thu chay truc tiep neu khong qua WSL
            try:
                process = subprocess.Popen(
                    [target_bin],
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
                stdout, stderr = process.communicate(input=f"{test_pin}\n", timeout=2)
            except Exception:
                pass

    print(f"[+] Blackbox Fuzzing Completed. Total Crashes/Anomalies: {crashes}")

if __name__ == "__main__":
    run_blackbox_fuzzer()