import re, os

DANGEROUS_PATTERNS = [
    (r'\bstrcpy\s*\(', "CWE-120: Su dung strcpy nguy hiem"),
    (r'\bsprintf\s*\(', "CWE-120: Su dung sprintf nguy hiem")
]

def scan_code():
    print("[*] Pattern Scanner dang quet ma nguon C...")
    for root, _, files in os.walk("../src"):
        for f in files:
            if f.endswith('.c'):
                with open(os.path.join(root, f), 'r') as file:
                    for idx, line in enumerate(file, 1):
                        for pat, msg in DANGEROUS_PATTERNS:
                            if re.search(pat, line):
                                print(f"  [CANH BAO] {f}:{idx} -> {msg}")

if __name__ == "__main__":
    scan_code()