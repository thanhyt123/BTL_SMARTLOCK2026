import z3

def verify_lock_logic():
    """Kiểm chứng tính đúng đắn của logic khóa thông minh bằng Z3 SMT Solver."""
    print("[+] Starting SMT Logic Verification with Z3...")
    
    solver = z3.Solver()
    
    # Khai báo các biến trạng thái
    pin_correct = z3.Bool('pin_correct')
    attempts = z3.Int('attempts')
    locked_out = z3.Bool('locked_out')
    door_unlocked = z3.Bool('door_unlocked')
    
    # Ràng buộc hệ thống (System Invariants)
    # 1. Nếu số lần thử vượt quá 3, hệ thống bị khóa
    solver.add(z3.Implies(attempts >= 3, locked_out))
    
    # 2. Cửa chỉ mở khi PIN đúng VÀ chưa bị khóa hệ thống
    solver.add(door_unlocked == z3.And(pin_correct, z3.Not(locked_out)))
    
    # Tình huống kiểm chứng (Property Check):
    # Liệu cửa có thể mở khi đã thử sai quá 3 lần (locked_out = True)?
    solver.push()
    solver.add(attempts >= 3, door_unlocked == True)
    
    result = solver.check()
    
    print("\n--- SMT Verification Result ---")
    if result == z3.unsat:
        print("[SUCCESS] Safety Property Holds: Door CANNOT be unlocked after 3 failed attempts.")
    elif result == z3.sat:
        print("[FAIL] Counterexample found! Door can be unlocked incorrectly:")
        print(solver.model())
    else:
        print("[?] Solver returned unknown.")
    solver.pop()

if __name__ == "__main__":
    verify_lock_logic()