from z3 import *

def check_buffer_overflow():
    print("[*] SMT Z3 Solver: Kiem tra an toan bo dem chuoi PIN...")
    buffer_size = 16
    input_length = Int('input_length')
    
    s = Solver()
    s.add(input_length >= 0)
    # Ràng buộc gây vi phạm overflow
    s.add(input_length >= buffer_size)
    
    if s.check() == sat:
        print("[!] CO LOI OVERFLOW! Z3 phat hien input_length vuot qua size:", s.model())
    else:
        print("[+] AN TOAN: Khong phat hien vi pham bo dem.")

if __name__ == "__main__":
    check_buffer_overflow()