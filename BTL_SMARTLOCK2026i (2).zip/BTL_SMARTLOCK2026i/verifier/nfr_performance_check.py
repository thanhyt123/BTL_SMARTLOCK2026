import os
import time
import subprocess

def run_nfr_check():
    print("[+] Starting NFR (Non-Functional Requirements) Performance Check...")
    
    target_bin = "./smart_lock.exe"
    if not os.path.exists("smart_lock.exe"):
        print("[-] Target binary 'smart_lock.exe' not found. Please compile the C project first.")
        return

    try:
        start_time = time.time()
        # Chay binary Linux qua WSL de khong bi loi WinError 216
        process = subprocess.Popen(
            ["wsl", target_bin],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        stdout, stderr = process.communicate(input="1234\n", timeout=5)
        end_time = time.time()

        execution_time = (end_time - start_time) * 1000  # ms
        print(f"[+] NFR Execution Time: {execution_time:.2f} ms")
        print("[+] NFR Performance Check PASSED!")

    except Exception as e:
        # Fallback chay truc tiep neu khong qua WSL
        try:
            start_time = time.time()
            process = subprocess.Popen(
                [target_bin],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            stdout, stderr = process.communicate(input="1234\n", timeout=5)
            print("[+] NFR Performance Check PASSED!")
        except Exception as err:
            print(f"[-] NFR Check Error: {err}")

if __name__ == "__main__":
    run_nfr_check()