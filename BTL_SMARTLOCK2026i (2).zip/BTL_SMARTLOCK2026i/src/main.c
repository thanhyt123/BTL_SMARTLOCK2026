#include "../include/smart_lock.h"
#include "../include/lock_auth.h"
#include "../include/lock_logger.h"
#include <stdio.h>

int main() {
    printf("=== SMARTHOME IOT LOCK SIMULATOR ===\n");
    SmartLock lock;
    smart_lock_init(&lock, "123456");

    process_pin_entry(&lock, "111111"); // Nhap sai 1
    process_pin_entry(&lock, "222222"); // Nhap sai 2
    process_pin_entry(&lock, "123456"); // Nhap dung -> Unlock

    return 0;
}