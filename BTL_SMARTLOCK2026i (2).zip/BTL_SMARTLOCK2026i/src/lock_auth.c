#include "../include/lock_auth.h"
#include <string.h>

int verify_pin(const char *input_pin, const char *master_pin) {
    if (input_pin == NULL || strlen(input_pin) != 6) {
        return ERR_INVALID_LEN;
    }
    if (strcmp(input_pin, master_pin) == 0) {
        return AUTH_SUCCESS;
    }
    return AUTH_FAIL;
}

int change_master_pin(char *current_master, const char *old_pin, const char *new_pin) {
    if (verify_pin(old_pin, current_master) == AUTH_SUCCESS) {
        if (strlen(new_pin) == 6) {
            strncpy(current_master, new_pin, 7);
            return AUTH_SUCCESS;
        }
    }
    return AUTH_FAIL;
}