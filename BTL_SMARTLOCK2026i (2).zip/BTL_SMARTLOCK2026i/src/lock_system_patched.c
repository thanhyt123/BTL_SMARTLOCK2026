#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void process_user_input_safe(const char *user_input) {
    char buffer[16];
    // FIX CWE-120: Su dung strncpy va dam bao null-terminator
    strncpy(buffer, user_input, sizeof(buffer) - 1);
    buffer[sizeof(buffer) - 1] = '\0';
    printf("Nhan du lieu nhap an toan: %s\n", buffer);
}

int main(int argc, char *argv[]) {
    if (argc > 1) {
        process_user_input_safe(argv[1]);
    } else {
        printf("Huong dan: %s <pin_code>\n", argv[0]);
    }
    return 0;
}