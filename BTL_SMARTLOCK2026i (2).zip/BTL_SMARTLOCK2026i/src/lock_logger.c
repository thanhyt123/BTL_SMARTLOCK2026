#include "../include/lock_logger.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

LockLogger* logger_init(uint32_t initial_capacity) {
    LockLogger *logger = (LockLogger*)malloc(sizeof(LockLogger));
    if (!logger) return NULL;
    logger->count = 0;
    logger->capacity = initial_capacity;
    logger->entries = (LogEntry*)malloc(sizeof(LogEntry) * initial_capacity);
    return logger;
}

void log_event(LockLogger *logger, const char *msg) {
    if (!logger || !logger->entries) return;
    if (logger->count >= logger->capacity) {
        logger->capacity *= 2;
        logger->entries = (LogEntry*)realloc(logger->entries, sizeof(LogEntry) * logger->capacity);
    }
    LogEntry *entry = &logger->entries[logger->count++];
    entry->timestamp = (uint32_t)time(NULL);
    strncpy(entry->event_msg, msg, sizeof(entry->event_msg) - 1);
    entry->event_msg[sizeof(entry->event_msg) - 1] = '\0';
    entry->is_encrypted = 0;
}

void free_logger(LockLogger *logger) {
    if (logger) {
        if (logger->entries) free(logger->entries);
        free(logger);
    }
}