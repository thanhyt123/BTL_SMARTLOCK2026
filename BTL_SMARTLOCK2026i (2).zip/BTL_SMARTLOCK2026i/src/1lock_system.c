#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "smart_lock.h"
#include "lock_auth.h"
#include "lock_logger.h"

#ifndef MAX_FAILED_ATTEMPTS
#define MAX_FAILED_ATTEMPTS 3
#endif

// Khoi tao biến logger toan cuc hoac dung logger trong Lock
static LockLogger g_logger;

void smart_lock_init(SmartLock *lock, const char *master_pin) {
    if (!lock) return;
    memset(lock, 0, sizeof(SmartLock));
    lock->failed_attempts = 0;
    
    if (master_pin) {
        strncpy(lock->master_pin, master_pin, sizeof(lock->master_pin) - 1);
    } else {
        strncpy(lock->master_pin, "1234", sizeof(lock->master_pin) - 1);
    }
    
    // Truyen con tro &g_logger thay vi truyen chuoi "SYSTEM_INIT"
    log_event(&g_logger, "Smart lock initialized successfully.");
}

int process_pin_entry(SmartLock *lock, const char *input_pin) {
    if (!lock || !input_pin) return -1;

    // Kiem tra nguong lockout
    if (lock->failed_attempts >= MAX_FAILED_ATTEMPTS) {
        log_event(&g_logger, "System is LOCKED OUT due to too many failed attempts.");
        return 2;
    }

    // Kiem tra PIN bang thu vien authentication
    if (verify_pin(lock->master_pin, input_pin) == 0) {
        lock->failed_attempts = 0;
        log_event(&g_logger, "Door unlocked successfully.");
        return 0;
    } else {
        lock->failed_attempts++;
        log_event(&g_logger, "Incorrect PIN entered.");
        
        if (lock->failed_attempts >= MAX_FAILED_ATTEMPTS) {
            log_event(&g_logger, "Max failed attempts reached. System locked.");
            return 2;
        }
        return 1;
    }
}

int lock_system_demo(void) {
    SmartLock lock;
    smart_lock_init(&lock, "1234");

    printf("=== SMART LOCK C SIMULATOR ===\n");
    process_pin_entry(&lock, "0000");
    process_pin_entry(&lock, "1234");

    return 0;
}