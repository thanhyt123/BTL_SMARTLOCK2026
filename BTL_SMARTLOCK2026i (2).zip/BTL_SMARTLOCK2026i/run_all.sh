#!/bin/bash
# =====================================================================
# BTL_SMARTLOCK2026 - AUTOMATED TOOLCHAIN RUNNER
# =====================================================================

echo "============================================================"
echo "[1/3] KIEM CHUNG LOGIC KRIPKE BANG Z3 SMT PROVER"
echo "============================================================"
python3 verifier/kripke_bmc.py
if [ $? -ne 0 ]; then
    echo "[!] Kiem chung Z3 thieu hut hoac vi pham thuoc tinh an toan!"
    exit 1
fi

echo ""
echo "============================================================"
echo "[2/3] RA QUET TINH PATTERN SCANNER (CWE-120, CWE-532)"
echo "============================================================"
python3 verifier/pattern_scanner.py

echo ""
echo "============================================================"
echo "[3/3] BIEN DICH VA CHAY MO PHONG C SIMULATOR (4 LOCKS)"
echo "============================================================"
gcc -Wall -Wextra -Iinclude src/main.c src/lock_auth.c src/lock_logger.c src/smart_lock.c -o smart_lock
./smart_lock

echo ""
echo "============================================================"
echo "[THANH CONG] DA CHAY XONG TOAN BO LUONG 1 MACH!"
echo "============================================================"