@echo off
chcp 65001 > nul
cls

echo ====================================================
echo [1/3] KIEM CHUNG LOGIC KRIPKE BANG Z3 SMT PROVER
echo ====================================================
python verifier/kripke_bmc.py
python verifier/1check_z3.py
python verifier/smt_verify.py

echo.
echo ====================================================
echo [2/3] BIEN DICH CHUONG TRINH C TRUOC
echo ====================================================
wsl gcc -w -Iinclude src/main.c src/lock_auth.c src/lock_logger.c src/1lock_system.c -o smart_lock.exe

echo.
echo ====================================================
echo [3/3] RA QUET TINH PATTERN SCANNER VA FUZZING
echo ====================================================
python verifier/pattern_scanner.py
python verifier/memory_trace_demo.py
python verifier/fuzzer_blackbox.py
python verifier/fuzzer_whitebox.py
python verifier/nfr_performance_check.py

echo.
echo ====================================================
echo [4/4] CHAY MO PHONG C SIMULATOR
echo ====================================================
if exist smart_lock.exe (
    wsl ./smart_lock.exe
) else (
    echo [-] Khong tim thay file thuc thi smart_lock.exe!
)

echo.
echo ====================================================
echo [THANH CONG] DA CHAY XONG TOAN BO LUONG 1 MACH!
echo ====================================================